package interfaceGrafica;


import javax.swing.JFrame;

public class Janela extends JFrame {
	Mesa jan = new Mesa();
	public boolean vdd=false; 
	
	public Janela() {		
	 	jan.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jan.setSize(500,445);
		jan.setResizable(true);			
		jan.setVisible(true);				
	}	

}
