package interfaceGrafica;


import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JFrame;
import negocio.Negocio;


public class Mesa extends JFrame {	
	
	private Negocio n = new Negocio();		
	private int par=0;
	private JButton[] o = new JButton [24];
	int[] a =  {0,2,3};	
	private Object opc;
	private Object[] op = {"Dificuldade F�cil: 16 cartas","Dificuldade Dif�cil: 24 cartas"};	
	private String aux;
	Random rnd = new Random();	
	private String virada = null; 
	private MouseEvent click;
	
	
	public Mesa() {			
		super("Jogo da Memoria");
		setLayout(new FlowLayout());
		
		opc = JOptionPane.showInputDialog(null,"Escolha a dificuldade", "Op�ao",
	            JOptionPane.INFORMATION_MESSAGE, null,
	                op,op[0]); 	    
	   mostra();
			
	}
	
	public void mostra() {
		
		if (this.opc == op[0]) {
			n.baralhos(1);			
			setLayout(new GridLayout(4,4,1,1));
			for (int i=0; i<16;i++) {
				aux  = n.dif1.get(rnd.nextInt(16)).toString();
				//System.out.println(aux);
				o[i] = new JButton(aux);	
				add(o[i]);
				//addMouseListener(new MouseClique());
				
				
			}
			boActionPerfomermed(click, o,8);
			
		}
		
		if (this.opc == op[1] ) {
			n.baralhos(2);
			setLayout(new GridLayout(4,6,1,1));
			for (int i=0; i<24;i++) {
				aux  = n.dif1.get(rnd.nextInt(24)).toString();
				o[i] = new JButton(aux);			
				add(o[i]);
				//addMouseListener(new MouseClique());
			}
			boActionPerfomermed(click, o,12);
		}
	}
	
	private void boActionPerfomermed (MouseEvent click, JButton[] o, int pares) {				
		while(par < pares) {
			String nome = o[click.getButton()].getActionCommand();
			if (nome == null) {				
				virada = nome;
				System.out.println("oi");
				
			}else {
				if (virada == nome) {
					par++;
				}
			}
			if (par == pares) {
				JOptionPane.showMessageDialog(this, "O jogo acabou",
						"Fim de jogo",
						JOptionPane.INFORMATION_MESSAGE);
			
		  }
		}
	}
}
