package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dados.Carta;
import exception.SelectException;

public class CartaDAO {
	
	private static CartaDAO instance = null;
	private PreparedStatement select;	
	private PreparedStatement selectAll ;

	
	public static CartaDAO getInstance() throws ClassNotFoundException, SQLException, SelectException{
		if (instance == null) {
			instance = new CartaDAO();
		}
		return instance;
	}
	
	private CartaDAO() throws ClassNotFoundException, SQLException, SelectException{
		Connection conexao = Conexao.getConexao();		
		select = conexao.prepareStatement("select * from cartas where id = ?" );
		selectAll = conexao.prepareStatement("select * from cartas"); 
	}
	public List<Carta> selectAll() throws SelectException{
		ResultSet rs;
		Carta carta = null;
		List<Carta> cartas = new ArrayList<Carta>();
		try {
			
			rs = selectAll.executeQuery();
			while (rs.next()) {
				carta = new Carta();
				carta.setId(rs.getInt("id"));
				carta.setNome(rs.getString("nome"));
				cartas.add(carta);
				
			}
			return cartas;
		} catch (SQLException e) {
			throw new SelectException("Erro");
		}
	}
	
	public Carta select(int id) throws SelectException{
		ResultSet rs;
		Carta carta = null;
		try {
			select.setInt(1, id);
			rs = select.executeQuery();
			if (rs.next()) {
				carta = new Carta();
				carta.setId(rs.getInt("id"));
				carta.setNome(rs.getString("nome"));				
			}
			return carta;
		} catch (SQLException e) {
			throw new SelectException("Erro aqui");
		}
	}
	
	
}
