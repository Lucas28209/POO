package apresentacao;

import interfaceGrafica.*;
import negocio.Negocio;
public class Principal  {  
	  
	 public static void main(String args[]) {
		 Negocio n = new Negocio(); 		 
		 Janela j = new Janela();	 
		 
	 }	 
	
}
