package negocio;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import dados.Carta;
import exception.SelectException;
import persistencia.CartaDAO;
import persistencia.Conexao;

//import java.util.Timer;

public class Negocio  {
	
	public List<Carta> c = new ArrayList<Carta>();
	public Random ale = new Random();
	public List<Carta> dif1 = new ArrayList<Carta>(16);
	public List<Carta> dif2 = new ArrayList<Carta>(24);

	public String aux; 

	public void baralhos(int escolha) {
			
			Conexao.setSenha("postgres");		 
		 try {
			 CartaDAO cartaDAO = CartaDAO.getInstance();
			 c = cartaDAO.selectAll();		 
			 //System.out.println(c);	
			 
		 	} catch (SelectException e) {
		 		e.printStackTrace();
		 	} catch (ClassNotFoundException e) {
		 		e.printStackTrace();
		 	} catch (SQLException e) {
		 		e.printStackTrace();
		 	}
		 
		 if (escolha == 1) {			 
			 for (int i = 0; i<8; i++) {
				 dif1.add(c.get(ale.nextInt(40)));
				 //System.out.println(dif1);				
			 }
			 dif1.addAll(dif1);			
			 System.out.println(dif1);	 
		 } else {		 
			 if (escolha == 2){
				 for (int i = 0; i<16; i++) {
					 dif2.add(c.get(ale.nextInt(40)));
					 //System.out.println(dif1);				
				 }
				 dif2.addAll(dif2);			
				 System.out.println(dif2);			 
			 }
		 	}
		aux = dif1.get(0).toString();
		System.out.println(aux);
		//setAux(aux); 
		  		 
	}
	
	public String getAux() {
		return aux;
	}

	public void setAux(String aux) {
		this.aux = aux;
	}

	public Negocio() {
				
	}
	
	
	public List<Carta> getDif1() {
		return dif1;
	}

	public void setDif1(List<Carta> dif1) {
		this.dif1 = dif1;
	}

	public List<Carta> getDif2() {
		return dif2;
	}

	public void setDif2(List<Carta> dif2) {
		this.dif2 = dif2;
	}

	public List<Carta> getC() {
		return c;
	}
	

	public void setC(List<Carta> c) {
		this.c = c;
	}
	
	public String dif1(int i) {
		return dif1.get(i).toString();
	}
	
	public String toString() {
		return "\nLista = " + getC();
	}
	

}
